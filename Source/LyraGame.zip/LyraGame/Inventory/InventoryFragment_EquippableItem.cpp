// Copyright Epic Games, Inc. All Rights Reserved.

#include "InventoryFragment_EquippableItem.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(InventoryFragment_EquippableItem)

