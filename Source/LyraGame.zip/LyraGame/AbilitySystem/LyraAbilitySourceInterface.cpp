// Copyright Epic Games, Inc. All Rights Reserved.

#include "LyraAbilitySourceInterface.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(LyraAbilitySourceInterface)

ULyraAbilitySourceInterface::ULyraAbilitySourceInterface(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{}

