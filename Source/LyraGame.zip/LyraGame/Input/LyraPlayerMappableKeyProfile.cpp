// Copyright Epic Games, Inc. All Rights Reserved.

#include "Input/LyraPlayerMappableKeyProfile.h"

void ULyraPlayerMappableKeyProfile::EquipProfile()
{
	Super::EquipProfile();

	// Do anything you may want to when a new key profile is equipped
}

void ULyraPlayerMappableKeyProfile::UnEquipProfile()
{
	Super::UnEquipProfile();
	
	// Do anything you may want to when a new key profile is unequipped
}
